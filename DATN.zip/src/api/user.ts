import axios from 'axios';

const API_URL = 'https://jsonplaceholder.typicode.com/users';

export async function getUsers() {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Lỗi khi lấy danh sách người dùng:', error);
    return [];
  }
}