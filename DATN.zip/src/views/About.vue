<script setup lang="ts">
import { ref, onMounted } from 'vue';
// import { getUsers } from '@/api/user';

// const users = ref([]);

// onMounted(async () => {
//   users.value = await getUsers();
// });
</script>

<template>
  <div>
    <h1>About</h1>
  </div>
</template>