<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';

interface ExpertProfile {
  avatar: string;
  fullName: string;
  email: string;
  specialty: string;
  workplace: string;
  bio: string;
  adviceList: {
    id: number;
    title: string;
    content: string;
    date: string;
    likes: number;
    comments: number;
  }[];
}

const router = useRouter();
const profile = ref<ExpertProfile>({
  avatar: '/images/avatar-default.jpg',
  fullName: 'BS. Nguyễn Văn A',
  email: 'bs.nguyenvana@example.com',
  specialty: 'Y học cổ truyền',
  workplace: 'Bệnh viện Y học cổ truyền',
  bio: 'Bác sĩ chuyên khoa Y học cổ truyền với 10 năm kinh nghiệm trong lĩnh vực chẩn đoán và điều trị bệnh bằng phương pháp Đông y. Tôi đã điều trị thành công cho hàng nghìn bệnh nhân mắc các bệnh mãn tính và cấp tính bằng các phương pháp y học cổ truyền.',
  adviceList: [
    {
      id: 1,
      title: 'Cách phòng ngừa cảm cúm theo Đông y',
      content: 'Sử dụng các loại thảo dược như gừng, tía tô, tỏi...',
      date: '2024-03-20',
      likes: 120,
      comments: 15
    },
    {
      id: 2,
      title: 'Phương pháp điều trị mất ngủ',
      content: 'Kết hợp các bài thuốc Đông y với liệu pháp tâm lý...',
      date: '2024-03-18',
      likes: 85,
      comments: 12
    },
    {
      id: 3,
      title: 'Cách tăng cường sức đề kháng',
      content: 'Sử dụng các bài thuốc bổ dưỡng và thực phẩm chức năng...',
      date: '2024-03-15',
      likes: 150,
      comments: 20
    }
  ]
});

const handleEditProfile = () => {
  // TODO: Implement edit profile functionality
  console.log('Edit profile clicked');
};


</script>

<template>
  <div class="profile-page">
    <!-- Profile Header -->
    <div class="profile-header">
      <img :src="'\images\expert\a.png'" alt="Profile Avatar" class="avatar" >
      
      <div class="profile-info">
        <div class="avatar-container">
         
          
        </div>
        <div class="profile-details">
          <h1>{{ profile.fullName }}</h1>
          <p class="specialty">{{ profile.specialty }}</p>
          <p class="workplace">{{ profile.workplace }}</p>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="profile-content">
      <div class="profile-grid">
        <!-- Left Column -->
        <div class="profile-main">
          <!-- About Section -->
          <section class="profile-section">
            <div class="section-header">
              <h2>Giới thiệu</h2>
              <button class="edit-btn" >
                <i class="fas fa-edit"></i> Chỉnh sửa
              </button>
            </div>
            <div class="section-content">
              <p>{{ profile.bio }}</p>
            </div>
          </section>

          <!-- Advice List Section -->
          <section class="profile-section">
            <div class="section-header">
              <h2>Lời khuyên đã đăng</h2>
              <button class="edit-btn" >
                <i class="fas fa-edit"></i> Chỉnh sửa
              </button>
            </div>
            <div class="section-content">
              <div class="advice-list">
                <div v-for="advice in profile.adviceList" :key="advice.id" class="advice-item">
                  <div class="advice-header">
                    <h3>{{ advice.title }}</h3>
                    <span class="advice-date">{{ advice.date }}</span>
                  </div>
                  <p class="advice-content">{{ advice.content }}</p>
                  <div class="advice-stats">
                    
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        <!-- Right Column -->
        <div class="profile-sidebar">
          <!-- Contact Info -->
          <section class="profile-section">
            <div class="section-header">
              <h2>Thông tin liên hệ</h2>
              <button class="edit-btn" @click="handleEditProfile">
                <i class="fas fa-edit"></i> Chỉnh sửa
              </button>
            </div>
            <div class="section-content">
              <div class="contact-info">
                <div class="info-item">
                  <i class="fas fa-envelope"></i>
                  <span>{{ profile.email }}</span>
                </div>
                <div class="info-item">
                  <i class="fas fa-hospital"></i>
                  <span>{{ profile.workplace }}</span>
                </div>
              </div>
            </div>
          </section>

          
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.profile-page {
  min-height: 100vh;
  background-color: #f5f7fa;
  padding-top: 60px;
}

.profile-header {
  position: relative;
  height: 300px;
  background-color: #fff;
  margin-bottom: 2rem;
}

.profile-cover {
  height: 200px;
  background: linear-gradient(135deg, #008053 0%, #00a86b 100%);
}

.profile-info {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 0 2rem;
  display: flex;
  align-items: flex-end;
  gap: 2rem;
}

.avatar-container {
  position: relative;
  margin-bottom: -50px;
}

.avatar {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  border: 4px solid #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.edit-avatar-btn {
  position: absolute;
  bottom: 0;
  right: 0;
  background: #008053;
  color: white;
  border: none;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.edit-avatar-btn:hover {
  background: #006c46;
  transform: scale(1.1);
}

.profile-details h1 {
  margin: 0;
  font-size: 2rem;
  color: #2c3e50;
}

.specialty {
  color: #008053;
  margin: 0.5rem 0;
  font-weight: 500;
}

.workplace {
  color: #666;
  margin: 0.5rem 0;
}

.profile-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
}

.profile-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
}

.profile-section {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 2rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
}

.section-header h2 {
  margin: 0;
  color: #2c3e50;
  font-size: 1.5rem;
}

.edit-btn {
  background: none;
  border: none;
  color: #008053;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  transition: all 0.3s ease;
}

.edit-btn:hover {
  background: rgba(0, 128, 83, 0.1);
}

.advice-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.advice-item {
  padding: 1.5rem;
  background: #f8f9fa;
  border-radius: 8px;
  border-left: 4px solid #008053;
  transition: all 0.3s ease;
}

.advice-item:hover {
  transform: translateX(5px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.advice-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.5rem;
}

.advice-header h3 {
  margin: 0;
  font-size: 1.1rem;
  color: #2c3e50;
}

.advice-date {
  font-size: 0.8rem;
  color: #999;
}

.advice-content {
  margin: 0.5rem 0;
  color: #666;
  font-size: 0.95rem;
  line-height: 1.5;
}

.advice-stats {
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #666;
  font-size: 0.9rem;
}

.stat-item i {
  color: #008053;
}

.contact-info {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  color: #666;
}

.info-item i {
  color: #008053;
  width: 20px;
}

.logout-btn {
  width: 100%;
  padding: 1rem;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  font-size: 1rem;
  transition: all 0.3s ease;
}

.logout-btn:hover {
  background: #c82333;
}

@media (max-width: 768px) {
  .profile-grid {
    grid-template-columns: 1fr;
  }

  .profile-info {
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: 1rem;
  }

  .profile-content {
    padding: 0 1rem;
  }

  .advice-header {
    flex-direction: column;
    gap: 0.5rem;
  }
}
</style> 